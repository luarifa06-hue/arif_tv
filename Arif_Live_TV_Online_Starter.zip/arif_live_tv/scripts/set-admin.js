// Run once on a trusted computer after installing firebase-admin:
// npm init -y && npm install firebase-admin
// Download a Firebase service-account JSON and set GOOGLE_APPLICATION_CREDENTIALS.
// Usage: node set-admin.js admin@example.com
const admin = require('firebase-admin');
const email = process.argv[2];
if (!email) throw new Error('Usage: node set-admin.js admin@example.com');
admin.initializeApp({ credential: admin.credential.applicationDefault() });
(async () => {
  const user = await admin.auth().getUserByEmail(email);
  await admin.auth().setCustomUserClaims(user.uid, { admin: true });
  console.log(`Admin permission enabled for ${email}. Sign out and sign in again.`);
  process.exit(0);
})().catch(e => { console.error(e); process.exit(1); });
