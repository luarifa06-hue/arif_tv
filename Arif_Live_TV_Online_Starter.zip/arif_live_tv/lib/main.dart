import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';

// Run `flutterfire configure` to generate this file before building.
import 'firebase_options.dart';

const bg = Color(0xFF080D18);
const panel = Color(0xFF101827);
const green = Color(0xFF10C58A);
const muted = Color(0xFF8793A8);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
  runApp(const ArifLiveTV());
}

class ArifLiveTV extends StatelessWidget {
  const ArifLiveTV({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
    debugShowCheckedModeBanner: false,
    title: 'Arif Live TV',
    theme: ThemeData(
      brightness: Brightness.dark,
      scaffoldBackgroundColor: bg,
      colorScheme: const ColorScheme.dark(primary: green, surface: panel),
      useMaterial3: true,
      fontFamily: 'Roboto',
    ),
    home: const HomePage(),
  );
}

class Channel {
  final String id, name, category, logo, streamUrl;
  final bool featured;
  Channel({required this.id, required this.name, required this.category,
    required this.logo, required this.streamUrl, this.featured = false});
  factory Channel.fromDoc(DocumentSnapshot<Map<String, dynamic>> doc) {
    final d = doc.data() ?? {};
    return Channel(
      id: doc.id,
      name: (d['name'] ?? 'Unnamed channel').toString(),
      category: (d['category'] ?? 'অন্যান্য').toString(),
      logo: (d['logo'] ?? '').toString(),
      streamUrl: (d['streamUrl'] ?? '').toString(),
      featured: d['featured'] == true,
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final search = TextEditingController();
  String category = 'সব চ্যানেল';
  final favorites = <String>{};
  static const categories = ['সব চ্যানেল', 'প্রিয়', 'সংবাদ', 'বিনোদন', 'খেলাধুলা', 'অন্যান্য'];

  @override
  void dispose() { search.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: StreamBuilder<QuerySnapshot<Map<String, dynamic>>>(
          stream: FirebaseFirestore.instance.collection('channels')
              .where('active', isEqualTo: true).snapshots(),
          builder: (context, snapshot) {
            final all = (snapshot.data?.docs ?? []).map(Channel.fromDoc).toList();
            final q = search.text.trim().toLowerCase();
            final channels = all.where((c) {
              final categoryOk = category == 'সব চ্যানেল' ||
                (category == 'প্রিয়' ? favorites.contains(c.id) : c.category == category);
              return categoryOk && c.name.toLowerCase().contains(q);
            }).toList();
            final featured = all.where((c) => c.featured).firstOrNull ??
                (all.isNotEmpty ? all.first : null);

            return CustomScrollView(slivers: [
              SliverToBoxAdapter(child: _header()),
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 14),
                child: TextField(
                  controller: search,
                  onChanged: (_) => setState(() {}),
                  decoration: InputDecoration(
                    hintText: 'লাইভ টিভি চ্যানেল খুঁজুন...',
                    prefixIcon: const Icon(Icons.search, color: green),
                    filled: true, fillColor: panel,
                    border: OutlineInputBorder(borderRadius: BorderRadius.circular(18),
                      borderSide: const BorderSide(color: Color(0xFF29344A))),
                  ),
                ),
              )),
              if (featured != null)
                SliverToBoxAdapter(child: _featured(featured)),
              SliverToBoxAdapter(child: SizedBox(
                height: 58,
                child: ListView.separated(
                  padding: const EdgeInsets.symmetric(horizontal: 16),
                  scrollDirection: Axis.horizontal,
                  itemCount: categories.length,
                  separatorBuilder: (_, __) => const SizedBox(width: 8),
                  itemBuilder: (context, i) {
                    final item = categories[i], selected = category == item;
                    return ChoiceChip(
                      label: Text(item),
                      selected: selected,
                      onSelected: (_) => setState(() => category = item),
                      selectedColor: green,
                      backgroundColor: panel,
                      labelStyle: TextStyle(color: selected ? bg : Colors.white,
                        fontWeight: FontWeight.w700),
                      side: BorderSide(color: selected ? green : const Color(0xFF29344A)),
                    );
                  },
                ),
              )),
              SliverToBoxAdapter(child: Padding(
                padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
                child: Row(children: [
                  Container(width: 4, height: 22, decoration: BoxDecoration(
                    color: green, borderRadius: BorderRadius.circular(4))),
                  const SizedBox(width: 9),
                  Text('${channels.length} টি চ্যানেল',
                    style: const TextStyle(color: green, fontSize: 17, fontWeight: FontWeight.bold)),
                ]),
              )),
              if (snapshot.connectionState == ConnectionState.waiting && all.isEmpty)
                const SliverFillRemaining(child: Center(child: CircularProgressIndicator(color: green)))
              else if (snapshot.hasError)
                SliverFillRemaining(child: Center(child: Text('ডেটা লোড হয়নি: ${snapshot.error}')))
              else if (channels.isEmpty)
                const SliverFillRemaining(child: Center(child: Text('এখনো কোনো চ্যানেল যোগ করা হয়নি')))
              else
                SliverPadding(
                  padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                  sliver: SliverGrid(
                    delegate: SliverChildBuilderDelegate(
                      (context, i) => _channelCard(channels[i]),
                      childCount: channels.length,
                    ),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 2, mainAxisSpacing: 12, crossAxisSpacing: 12,
                      childAspectRatio: .88,
                    ),
                  ),
                ),
            ]);
          },
        ),
      ),
    );
  }

  Widget _header() => Container(
    padding: const EdgeInsets.fromLTRB(18, 14, 18, 14),
    decoration: const BoxDecoration(
      border: Border(bottom: BorderSide(color: Color(0xFF164C42))),
      color: Color(0xFF0B1220),
    ),
    child: Row(children: [
      Container(width: 54, height: 54, alignment: Alignment.center,
        decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(14)),
        child: const Icon(Icons.live_tv, color: green, size: 34)),
      const SizedBox(width: 12),
      const Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text('ARIF LIVE TV', style: TextStyle(fontSize: 21, fontWeight: FontWeight.w900)),
        SizedBox(height: 3),
        Text('● অন-এয়ার • লাইভ টিভি', style: TextStyle(color: green, fontSize: 12)),
      ])),
      IconButton(onPressed: () => setState(() => category = 'প্রিয়'),
        icon: const Icon(Icons.favorite, color: Color(0xFFFF6688))),
      IconButton(onPressed: () => showAboutDialog(context: context,
        applicationName: 'Arif Live TV', applicationVersion: '1.0.0'),
        icon: const Icon(Icons.settings, color: Colors.amber)),
    ]),
  );

  Widget _featured(Channel c) => Container(
    margin: const EdgeInsets.fromLTRB(14, 4, 14, 14),
    padding: const EdgeInsets.all(10),
    decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(22),
      border: Border.all(color: const Color(0xFF17644F))),
    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
      InkWell(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(channel: c))),
        child: Container(height: 190, decoration: BoxDecoration(
          color: const Color(0xFF172236), borderRadius: BorderRadius.circular(14)),
          child: c.logo.isNotEmpty
            ? ClipRRect(borderRadius: BorderRadius.circular(14),
                child: Image.network(c.logo, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, size: 70, color: green)))
            : const Icon(Icons.live_tv, size: 70, color: green)),
      ),
      const SizedBox(height: 10),
      Row(children: [
        const Icon(Icons.circle, color: green, size: 10),
        const SizedBox(width: 7),
        Expanded(child: Text('এখন চলছে: ${c.name}', maxLines: 1,
          style: const TextStyle(fontWeight: FontWeight.bold))),
        TextButton(onPressed: () => Navigator.push(context,
          MaterialPageRoute(builder: (_) => PlayerPage(channel: c))),
          child: const Text('WATCH LIVE')),
      ]),
    ]),
  );

  Widget _channelCard(Channel c) {
    final isFav = favorites.contains(c.id);
    return InkWell(
      borderRadius: BorderRadius.circular(20),
      onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => PlayerPage(channel: c))),
      child: Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(color: panel, borderRadius: BorderRadius.circular(20),
          border: Border.all(color: isFav ? green : const Color(0xFF253047))),
        child: Column(children: [
          Expanded(child: Container(width: double.infinity, decoration: BoxDecoration(
            color: Colors.white, shape: BoxShape.circle, border: Border.all(color: const Color(0xFFBCC5D2), width: 3)),
            clipBehavior: Clip.antiAlias,
            child: c.logo.isEmpty
              ? const Icon(Icons.live_tv, color: green, size: 54)
              : Image.network(c.logo, fit: BoxFit.contain,
                  errorBuilder: (_, __, ___) => const Icon(Icons.live_tv, color: green, size: 54)))),
          const SizedBox(height: 9),
          Text(c.name, maxLines: 1, overflow: TextOverflow.ellipsis,
            style: const TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
          Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(c.category, style: const TextStyle(color: muted, fontSize: 12)),
            IconButton(
              visualDensity: VisualDensity.compact,
              onPressed: () => setState(() => isFav ? favorites.remove(c.id) : favorites.add(c.id)),
              icon: Icon(isFav ? Icons.favorite : Icons.favorite_border,
                color: isFav ? const Color(0xFFFF6688) : muted, size: 19)),
          ]),
        ]),
      ),
    );
  }
}

class PlayerPage extends StatefulWidget {
  final Channel channel;
  const PlayerPage({super.key, required this.channel});
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  VideoPlayerController? controller;
  String? error;
  bool loading = true;

  @override
  void initState() { super.initState(); _start(); }

  Future<void> _start() async {
    final url = widget.channel.streamUrl;
    if (url.isEmpty) {
      setState(() { loading = false; error = 'এই চ্যানেলের স্ট্রিম URL এখনো যোগ করা হয়নি।'; });
      return;
    }
    try {
      final c = VideoPlayerController.networkUrl(Uri.parse(url));
      controller = c;
      await c.initialize();
      await c.play();
      if (mounted) setState(() => loading = false);
    } catch (_) {
      if (mounted) setState(() { loading = false; error = 'ভিডিও চালু করা যায়নি। স্ট্রিম URL পরীক্ষা করুন।'; });
    }
  }

  @override
  void dispose() { controller?.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(widget.channel.name), backgroundColor: bg),
    body: Column(children: [
      AspectRatio(aspectRatio: 16 / 9, child: Container(color: Colors.black,
        child: Center(child: loading ? const CircularProgressIndicator(color: green)
          : error != null ? Padding(padding: const EdgeInsets.all(20), child: Text(error!, textAlign: TextAlign.center))
          : GestureDetector(onTap: () => setState(() {}),
              child: Stack(alignment: Alignment.center, children: [
                VideoPlayer(controller!),
                IconButton(
                  iconSize: 58, color: Colors.white,
                  onPressed: () => setState(() {
                    controller!.value.isPlaying ? controller!.pause() : controller!.play();
                  }),
                  icon: Icon(controller!.value.isPlaying ? Icons.pause_circle : Icons.play_circle),
                ),
              ])),
      ))),
      ListTile(leading: const Icon(Icons.live_tv, color: green),
        title: Text(widget.channel.name), subtitle: Text(widget.channel.category)),
    ]),
  );
}
