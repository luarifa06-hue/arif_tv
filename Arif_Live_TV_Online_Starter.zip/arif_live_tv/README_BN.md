# Arif Live TV — Android + Admin starter

এটি Flutter Android অ্যাপ ও Firebase-ভিত্তিক Admin Panel-এর প্রাথমিক সোর্স কোড। এটি এখনো APK নয়; Firebase কনফিগার করে Android build করতে হবে।

## কী আছে
- Dark UI, সবুজ accent, channel grid
- Search, category filter, favorites (বর্তমানে অ্যাপ চলাকালীন)
- Featured channel এবং HLS `.m3u8` player
- `admin/index.html` থেকে channel add/edit/delete
- Firestore security rules: public active-channel read, admin-only write

## প্রয়োজন
- Windows PC-তে Flutter SDK
- Android Studio + Android SDK
- Firebase account/project
- Android device বা emulator
- প্রতিটি চ্যানেলের অনুমোদিত logo URL এবং live stream URL

## Android app চালু
1. ZIP extract করো।
2. Flutter ও Android Studio install করো।
3. Terminal-এ project folder-এ গিয়ে চালাও:
   ```bash
   flutter pub get
   dart pub global activate flutterfire_cli
   firebase login
   flutterfire configure
   ```
4. `flutterfire configure` `lib/firebase_options.dart` তৈরি করবে।
5. Firebase Console-এ Firestore Database তৈরি করো।
6. `firebase/firestore.rules`-এর নিয়ম Firestore Rules-এ publish করো।
7. Android permission প্রয়োজন হলে `android/app/src/main/AndroidManifest.xml`-এ `<uses-permission android:name="android.permission.INTERNET"/>` আছে নিশ্চিত করো।
8. চালাও:
   ```bash
   flutter run
   ```
9. APK বানাতে:
   ```bash
   flutter build apk --release
   ```
   APK থাকবে `build/app/outputs/flutter-apk/app-release.apk`-এ।

## Firebase Admin Panel সেটআপ
1. Firebase Console → Project settings → General → Your apps → Web app তৈরি করো।
2. `admin/index.html`-এর `firebaseConfig`-এ নিজের Web config বসাও।
3. Authentication → Sign-in method থেকে Email/Password enable করো।
4. Authentication → Users থেকে admin email/password user তৈরি করো।
5. Firestore Database তৈরি করে `firebase/firestore.rules` publish করো।
6. নিরাপদ trusted computer-এ Firebase service-account credentials সেট করে:
   ```bash
   cd scripts
   npm init -y
   npm install firebase-admin
   node set-admin.js admin@example.com
   ```
   Service-account JSON কখনো ওয়েবসাইট, ZIP-এর public অংশ, বা অ্যাপে upload করবে না।
7. `admin/` folder Firebase Hosting বা অন্য HTTPS hosting-এ deploy করো। Admin page-এ তৈরি admin user দিয়ে login করো।

## Firestore channel document উদাহরণ
Collection: `channels`

```json
{
  "name": "Example News",
  "category": "সংবাদ",
  "logo": "https://example.com/logo.png",
  "streamUrl": "https://example.com/live/playlist.m3u8",
  "featured": true,
  "active": true
}
```

## গুরুত্বপূর্ণ
- শুধু নিজের বা ব্যবহারের অনুমতি আছে এমন TV stream URL যোগ করবে। কোনো চ্যানেলের stream URL অননুমোদিতভাবে কপি/রিব্রডকাস্ট করবে না।
- HLS stream অবশ্যই HTTPS ও compatible হতে হবে। কিছু provider domain restriction, token, geo restriction বা DRM ব্যবহার করে; সেক্ষেত্রে সাধারণ player-এ চলবে না।
- এই starter-এ কোনো বাস্তব চ্যানেলের URL অন্তর্ভুক্ত নেই।
- Admin panel-এ `firebaseConfig` placeholder বদলানো এবং Firebase rules/claims সেট করা বাধ্যতামূলক।
- Release-এর আগে Android app signing, app icon, privacy policy, error handling, device testing ও Play Store compliance সম্পন্ন করতে হবে।
