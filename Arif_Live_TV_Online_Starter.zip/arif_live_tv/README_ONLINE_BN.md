# Arif Live TV — সম্পূর্ণ অনলাইন Build/Deploy

এই ZIP-এ GitHub Actions workflow যোগ করা হয়েছে। GitHub-এ কোড রাখলে push করলেই APK ও Web build তৈরি হবে। Firebase Hosting secret/token সেট করলে Web app এবং `/admin` পেজ deploy হবে।

## ১) GitHub-এ প্রজেক্ট আপলোড
1. GitHub-এ sign in করে New repository তৈরি করো, নাম `arif-live-tv`।
2. ZIP extract করে সব ফাইল repository-তে upload করো (GitHub web UI → Add file → Upload files)।
3. `.github/workflows/build-deploy.yml` ফাইলটি অবশ্যই repository-তে থাকবে।
4. `lib/firebase_options.dart.example` ফাইলটি খুলে Copy করে `lib/firebase_options.dart` নামে নতুন ফাইল তৈরি করো।
5. Firebase project-এর আসল config বসিয়ে commit করো।

## ২) Firebase project
1. Firebase Console-এ project তৈরি করো।
2. Firestore Database তৈরি করো।
3. Authentication → Sign-in method → Email/Password enable করো।
4. Project settings → Your apps থেকে Web app ও Android app register করো।
5. Android package ID হবে `com.ariflivetv.app` (এটি Flutter Android build-এর applicationId-এর সঙ্গে মিলিয়ে নিতে হবে)।
6. Web app config থেকে API key, App ID, Sender ID, Project ID, Auth domain, Storage bucket নিয়ে `lib/firebase_options.dart`-এ বসাও।
7. Android app config থেকে Android App ID নিয়ে একই ফাইলে বসাও; API key, sender ID, project ID ও storage bucket Firebase project-এর তথ্য অনুযায়ী বসবে।
8. Firestore Rules-এ `firebase/firestore.rules`-এর নিয়ম publish করো।
9. Authentication → Users থেকে নিজের admin email/password user তৈরি করো।

## ৩) Admin claim সেট করা
Admin Panel-এ শুধু login করলেই admin হবে না। নিরাপদ Firebase Admin SDK credential দিয়ে user-কে `admin: true` custom claim দিতে হবে। `scripts/set-admin.js` এ কাজের উদাহরণ আছে। Service account JSON কখনো GitHub repository-তে commit করবে না।

## ৪) GitHub Actions দিয়ে APK ও Web build
1. GitHub repository → Settings → Secrets and variables → Actions।
2. Repository variable `FIREBASE_PROJECT_ID` তৈরি করে Firebase Project ID দাও।
3. Firebase CLI-এর মাধ্যমে পাওয়া deploy token-কে repository secret `FIREBASE_TOKEN` হিসেবে যোগ করো।
4. Actions tab → Build Arif Live TV → Run workflow।
5. সফল হলে workflow run-এর Artifacts অংশ থেকে `arif-live-tv-android-apk` এবং `arif-live-tv-web` নামের ফাইল নামানো যাবে।
6. Push to `main` করলেও workflow নিজে থেকে চলবে।

Firebase Hosting deploy করতে `FIREBASE_TOKEN` এবং `FIREBASE_PROJECT_ID` দুটোই লাগবে। এগুলো না থাকলে build artifact তৈরি হবে, কিন্তু hosting deploy step বাদ যাবে।

## ৫) সীমাবদ্ধতা ও নিরাপত্তা
- আমি তোমার GitHub/Firebase account-এ নিজে থেকে sign in বা deploy করতে পারি না। Account connection/permission ও project configuration তোমাকেই অনুমোদন করতে হবে।
- APK artifact হলো release build; Play Store publish/signing আলাদা ধাপ।
- কোনো live TV stream URL bundled নেই। শুধু তোমার নিজের বা ব্যবহারের লিখিত অনুমতি আছে এমন HTTPS HLS `.m3u8` URL যোগ করবে।
- কিছু stream DRM, token, geo restriction বা referer/header চায়; সেগুলো সাধারণ player-এ চলবে না।
- Admin panel `/admin/` path-এ থাকবে। Hosting deploy-এর আগে Firebase config বসাতে হবে।
